#include <stdio.h>
#include <string.h>
#include <locale.h>
#include "StoreWords.h"
#include "wordsAll.h"


int main(int argc, char *argv[]){
    setlocale(LC_ALL, "pt_PT.UTF-8");

		if(argc < 2){
			fprintf(stderr, "Erro argumentos");
			return 1;
		}

    DataStore data = {0};
    char linha[MAX_LINE_SIZE];

		for(int i = 1; i < argc; i++){ // percorre cada ficheiro 
			FILE *file = fopen(argv[i], "r");
			if(!file){
				fprintf(stderr, "Erro ao abrir ficheiro %s\n", argv[i]);
				continue;
			}

			while(fgets(linha, MAX_LINE_SIZE, file)){ // le cada linha do ficheiro
				utf8NormAll(linha);  // Normalizar a linha antes de processar
				wordProcess(linha, wordStore, &data);
			}

			fclose(file);
		}


		dataSort(&data);		
		printf("\nLista Ordenada\n");
		for(int i = 0; i < data.count; i++){//Percorre e coloca no stdout as palavras da lista
			printf("%s\n", data.words[i]);
		}	
		
		
		
		
    char strsearch[MAX_WORD_SIZE];

		while(printf("Palavra a pesquisar: "),fgets(strsearch, MAX_WORD_SIZE, stdin)){			
			int len = strlen(strsearch);
			if (len > 0 && strsearch[len - 1] == '\n')//Para remover o newline
				strsearch[len - 1] = '\0';
			
			
			
			utf8NormAll(strsearch);  // Normalizar 

			char *res = dataSearch(&data, strsearch);
			if(res){
				printf("Palavra encontrada\n");
			}else{
				printf("Palavra não existe\n");
			}
		}


    return 0;
}
