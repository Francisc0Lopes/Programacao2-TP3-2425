#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "StoreWords.h"
#include "wordsAll.h"
#include "locale.h"



int wordStore( char *word, void *context ){
	
	DataStore *store =(DataStore*)context;
	
	if(store->count > MAX_WORD_COUNT){
		fprintf(stderr, "%s","Array cheio\n");
		return 0;
	}
	
	for(int i= 0 ; i < store->count ; i++){
		if(strcmp(word, store->words[i])== 0){
			return 0;
		}
	}
	
    strcpy(store->words[store->count], word);
    store->count++;	
	return 1;
}

int dataComp( const void *c1, const void *c2){
	const char *str1 =(const char*)c1; 
	const char *str2 =(const char*)c2;
	return strcoll(str1,str2);
}

void dataSort( DataStore *data ){
	qsort(data->words,data->count,MAX_WORD_SIZE,dataComp);
	
}

char *dataSearch( DataStore *data, const char *sample ){	
	return bsearch(sample,data->words,data->count,MAX_WORD_SIZE,dataComp);
}


