#ifndef STOREWORDS_H
#define STOREWORDS_H
#define MAX_WORD_COUNT 1024
#define MAX_WORD_SIZE 1024
#define MAX_LINE_SIZE 1024



typedef struct{ 
int count; 
char words[MAX_WORD_COUNT][MAX_WORD_SIZE]; 
} DataStore; 



int wordStore( char *word, void *context ); 
int dataComp( const void *, const void * ); 
void dataSort( DataStore *data ); 
char *dataSearch( DataStore *data, const char *sample );

#endif
