#include <stdio.h>
#include <string.h>
#include "wordProc.h"

#define MAX_LINES 1024


int main(){
    char linhas[MAX_LINES][MAX];//1 MB maximo
    int total_linhas = 0;

		while (fgets(linhas[total_linhas], MAX, stdin) != NULL){//lê o stdin até EOF
			total_linhas++;
			if (total_linhas >= MAX_LINES){
				fprintf(stderr, "Número máximo de linhas excedido.\n");
				break;
			}
		}
		
		printf("\n");
		
		for (int i = 0; i < total_linhas; i++){ //separa as palavras e mete no stdout
			int n = wordProcess(linhas[i], wordPrint, stdout);  
			printf("\nLinha %d - Total de palavras : %d\n\n", i + 1, n);
		}
    
    return 0;
}
