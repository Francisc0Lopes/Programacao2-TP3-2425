#ifndef WORDPROC_H
#define WORDPROC_H
#define MAX 1024

/*
1. Separa as palavras existentes na string str, usando a função strtok da biblioteca normalizada 
2. Invoca sucessivamente a função passada em action, passando o endereço de cada uma das palavras identificadas e o parâmetro context. 
3. Os separadores são espaço " ", tabulação "\t" e mudança de linha "\n".
4. Retorna a soma dos valores retornados pelas sucessivas chamadas à função passada em action. 
 * */
int wordProcess( char *str, int (*action)( char *word, void *context ),void *context ); 

/*
1.destinada a ser passada no parâmetro action da função anterior para apresentar, numa stream de saída, a palavra passada no parâmetro word. 
2.O parâmetro context representa a stream onde são exibidas as palavras. 
3.A função retorna sempre 1. 
*/
int wordPrint( char *word, void *context ); 

#endif
