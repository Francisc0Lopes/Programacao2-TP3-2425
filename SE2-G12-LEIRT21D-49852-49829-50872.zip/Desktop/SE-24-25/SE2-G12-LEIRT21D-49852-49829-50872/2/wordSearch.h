#ifndef WORDSEARCH_H

int wordCheck( char *word, void *context);

#endif 
